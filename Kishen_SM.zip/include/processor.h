#ifndef PROCESSOR_H
#define PROCESSOR_H
#include <string>

class Processor {
 public:
  float Utilization();  

 private:
    std::string guest, guest_nice, idle, iowait, irq, nice, softirq, steal, system, user;  

};

#endif